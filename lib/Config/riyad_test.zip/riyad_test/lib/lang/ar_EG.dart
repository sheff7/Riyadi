const Map<String, String> ar_EG = {
  "hello": "مرحبًا",
  "find_your_venue": "ابحث عن مكانك!",
  "quick_booking": "الحجز السريع",
  "more": "أكثر",
  "ladies_only": "سيدات فقط",
  "choose_your_Sport": "اختر رياضتك",
};
