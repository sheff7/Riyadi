const Map<String, String> en_US = {
  "hello": "Hello",
  "find_your_venue": "Find  your venue!",
  "quick_booking": "Quick Booking",
  "more": "More",
  "ladies_only": "Ladies Only",
  "choose_your_sport": "Choose Your Sport"
};
