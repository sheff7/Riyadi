
class CachingKey  {
  static const String SETTINGS =  'SETTINGS';
  static const String PAGES =  'PAGES';
  static const String USER =  'USER';
  static const String LANGUAGE =  'LANGUAGE';
  static const String FCM_TOKEN =  'FCM_TOKEN';
  static const String LANGUAGE_SELECTED =  'LANGUAGE_SELECTED';


}
