class ApiConstant{
  static String BASE_URL= "https://.in/";
  // static String MAP_API_KEY="AIzaSyD_oTfjyZa2o7uncTRavR2jRPWmVhjpJsg";

}